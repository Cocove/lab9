package entity;

public interface Identifiable {
	int getId();
}
